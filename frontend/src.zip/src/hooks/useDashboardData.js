import { useEffect, useState } from 'react';
import {
  fetchDashboardSummary,
  fetchBudgetStatus,
  fetchUpcomingBills,
  fetchRecentTransactions,
} from '../services/dashboardService';

export function useDashboardData() {
  const [data, setData] = useState({
    summary: null,
    budgetStatus: [],
    upcomingBills: [],
    recentTransactions: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;

    async function loadAll() {
      setLoading(true);
      try {
        const [summary, budgetStatus, upcomingBills, recentTransactions] = await Promise.all([
          fetchDashboardSummary(),
          fetchBudgetStatus(),
          fetchUpcomingBills(),
          fetchRecentTransactions(5),
        ]);

        if (isMounted) {
          setData({ summary, budgetStatus, upcomingBills, recentTransactions });
        }
      } catch (err) {
        if (isMounted) setError(err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadAll();
    return () => {
      isMounted = false;
    };
  }, []);

  return { ...data, loading, error };
}