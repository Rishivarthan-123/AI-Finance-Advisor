import api from './api';

export async function fetchDashboardSummary() {
  const res = await api.get('/api/analytics/dashboard');
  return res.data; // { total_income, total_expense, balance, savings_rate }
}

export async function fetchBudgetStatus() {
  const res = await api.get('/api/budgets/status');
  return res.data.status; // [{ category, budget, spent, remaining, utilization }]
}

export async function fetchUpcomingBills() {
  const res = await api.get('/api/reminders/upcoming');
  return res.data; // [{ title, amount, due_date }]
}

export async function fetchRecentTransactions(limit = 5) {
  const res = await api.get('/api/transactions/');
  const transactions = res.data.transactions || [];
  return transactions
    .sort((a, b) => new Date(b.transaction_date) - new Date(a.transaction_date))
    .slice(0, limit);
}